<h2><?php echo $title ?></h2>

<?php echo form_open('index.php/auth/logout') ?>