     	</div><!--close content_item-->
      </div><!--close content-->   
	</div><!--close site_content-->  	
   <footer>
	 <p> Droit réserver <p>
    </footer>
    
  <script type="text/javascript" src="<?php echo base_url(assets/js/jquery.min.js);?>"></script>
  <script type="text/javascript" src="<?php echo base_url(assets/js/image_slide.js);?>"></script>
  
</body>
</html>