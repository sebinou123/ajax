<h2>Bravo ! upload avec succès</h2>
<p>Nombre de fichier lues : <?php echo $_SESSION['nombre_fichiers'];?><p>
<p>Nombre de nouvelle lues : <?php echo $_SESSION['nombre_nouvelle_lues'];?><p>
